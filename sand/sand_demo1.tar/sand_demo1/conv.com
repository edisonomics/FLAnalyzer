#!/bin/csh

if (`flagLoc $argv -help`) then
   echo "Format Conversions of Spectral Series Listed in a Metadata Table:"
   echo " -meta   metaName [meta.tab]       Metadata Table (INDEX DIR_NAME TITLE)."
   echo " -srcDir srcName  [.]              Source Directory."
   echo " -outDir outDir   [fid]            Optional Output Directory, or Keyword None."
   echo "Conversion Script Generation; Should be Last on Command-Line:"
   echo " -cmnd   convCmnd [bruker -AUTO]   Script Generation Command."
   exit 0
endif

set convCmnd = "bruker -AUTO"
set loc      = (`flagLoc $argv -cmnd`)
set thisArgv = ($argv)

if ($loc >= 1) then
   @ locP = $loc - 1
   @ locN = $loc + 1

   set convCmnd = ($argv[$locN-])
   set thisArgv = ($argv[1-$locP])
endif

set tabName = (`getArgD $thisArgv -meta   meta.tab`)
set srcDir  = (`getArgD $thisArgv -srcDir .`)
set outDir  = (`getArgD $thisArgv -outDir fid`)

#
#----------------------------------------------------------------------------------

set origDir = (`pwd`)

if (`string notcsame $outDir None`) then
   /bin/rm -rf $outDir 
   mkdir $outDir

   cd $outDir
      set outDirFull = (`pwd`)
   cd $origDir
endif 

set idList  = (`getTabCol.tcl -in $tabName -var INDEX`)
set dirList = (`getTabCol.tcl -in $tabName -var DIR_NAME`)
set titList = (`getTabCol.tcl -in $tabName -var TITLE`)

@ eCount = 0
@ i = 0
@ j = 0

foreach d ($dirList)
   @ i++

   cd $origDir
   cd $srcDir
   
   if (!(-d $d)) then
      echo "Conversion Error Finding Input Directory $d in $srcDir"
      @ eCount++
      continue
   endif

   @ j++

   cd $d
      set tStr = (`nmrPrintf "%03d-%s" $idList[$i] $titList[$i]`)

      /bin/rm -f test.fid fid.com conv.out

      $convCmnd >& conv.out

      if (!(-e fid.com)) then
         echo "Conversion Error Creating Conversion Script $d/fid.com in $srcDir"
         @ eCount++
         continue
      endif

      fid.com >>& conv.out

      if (!(-e test.fid)) then
         echo "Conversion Error Creating $d/test.fid in $srcDir"
         @ eCount++
         continue
      endif
      
      sethdr test.fid -title $tStr

      if (`string notcsame $outDir None`) then
         set thisName = (`nmrPrintf "%s/%s.fid" $outDirFull $tStr`)
         /bin/cp test.fid $thisName
      endif

      echo "$d test.fid $tStr"
      report2D.com test.fid
      echo ""

   cd $origDir
end

if ($eCount != 0) then
   echo "Conversion Notice: Errors Occurred During Conversion."
   exit 1
endif

exit 0
