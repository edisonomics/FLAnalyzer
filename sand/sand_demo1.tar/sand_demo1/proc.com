#!/bin/csh

set procArgs = "-xP0 Auto -xP1 0.0 -xBASEARG POLY,auto,ord=1,window=2% -apOrd 1 -apArgs apxP0Step=0.1"

if (`flagLoc $argv -help`) then
   echo "Process 1D Spectral Series Listed in a Metadata Table (1/23/2023):"
   echo " -in     metaName [meta.tab]       Metadata Table (INDEX DIR_NAME TITLE)."
   echo " -srcDir dirName  [.]              Source Directory."
   echo " -outDir outDir   [ft]             Output Directory."
   echo "Processing Options (Should be Last on Command Line):"
   echo " -procArgs  procArgs               Optional Arguments for basicFT1.com"
   echo "Default Processing Options:"
   echo " $procArgs"
   echo "Notes:"
   echo " 1. The input metadata table should include INDEX DIR_NAME TITLE."
   echo " 2. The input metadata table can optionally include P0 and P1. If"
   echo "    these are included in the table, they will over-ride any -xP0"
   echo "    or -xP1 settings provided to this script."
   exit 0
endif

set loc      = (`flagLoc $argv -procArgs`)
set thisArgv = ($argv)

if ($loc >= 1) then
   @ locP = $loc - 1
   @ locN = $loc + 1

   set procArgs = ($argv[$locN-])
   set thisArgv = ($argv[1-$locP])
endif

set srcDir  = (`getArgD $thisArgv -srcDir .`)
set outDir  = (`getArgD $thisArgv -outDir ft`)
set tabName = (`getArgD $thisArgv -in     meta.tab`)

echo ""
echo "Processing Options: $procArgs"
echo ""

#
#----------------------------------------------------------------------------------

set origDir  = (`pwd`)

cd $srcDir
   set fullSrcDir = (`pwd`)
cd $origDir

/bin/rm -rf $outDir 
mkdir $outDir 

cd $outDir
   set fullOutDir = (`pwd`)
cd $origDir

echo "Source Directory: $fullSrcDir"
echo "Output Directory: $fullOutDir"
echo ""

set idList  = (`getTabCol.tcl -in $tabName -var INDEX`)
set dirList = (`getTabCol.tcl -in $tabName -var DIR_NAME`)
set titList = (`getTabCol.tcl -in $tabName -var TITLE`)

set p0List  = (`getTabCol.tcl -in $tabName -var P0`)
set p1List  = (`getTabCol.tcl -in $tabName -var P1`)

set thisP0  = (`getArgD $procArgs -xP0 0.0`)
set thisP1  = (`getArgD $procArgs -xP1 0.0`)

if ($#p0List == 0) then
   echo "Using P0 specification from command-line and defaults (-xP0 $thisP0)."

   foreach d ($dirList)
      set p0List = ($p0List $thisP0)
   end
else
   echo "Using alternate specification of P0 from the metadata table ($tabName P0)."
endif

if ($#p1List == 0) then
   echo "Using P1 specification from command-line and defaults (-xP1 $thisP1)."

   foreach d ($dirList)
      set p1List = ($p1List $thisP1)
   end
else
   echo "Using alternate specification of P1 from the metadata table ($tabName P1)."
endif

echo ""

set adjArgs = (`stripArgs -xP0= -xP1= -- $procArgs`)
set maxList = ()

@ eCount = 0
@ i = 0
@ j = 0

foreach d ($dirList)
   @ i++

   if (!(-d $srcDir/$d)) then
      echo "Error Finding Input Directory $srcDir/$d"
      @ eCount++
      continue
   endif

   @ j++

   cd $srcDir/$d
      set inName = test.fid

      if (!(-e $inName)) then
         echo "Error Finding $srcDir/$d/$inName"
         exit 1
      endif

      set tStr    = (`getParm -in $inName -parm FDTITLE -dim NULL_DIM -text -fmt %s`)
      set outName = (`nmrPrintf "$fullOutDir/%s.ft1" $tStr`)

      /bin/rm -f test.ft1 nmr.com proc.out

      basicFT1.com -noexec -in $inName -out test.ft1 -xP0 $p0List[$i] -xP1 $p1List[$i] $procArgs >& proc.out

      if (!(-e nmr.com)) then
         echo "Error Creating Processing Script $srcDir/$d/nmr.com"
         @ eCount++
         continue
      endif

      nmr.com >>& proc.out

      if (!(-e test.ft1)) then
         echo "Error Creating $srcDir/$d/test.ft1 ($outName)"
         @ eCount++
         continue
      endif

      /bin/mv test.ft1 $outName

      echo "$d $outName $tStr"
      report2D.com $outName   
      echo ""

   cd $origDir
end

if ($eCount != 0) then
   echo "Conversion Notice: Errors Occurred During Processing."
   exit 1
endif

exit 0
