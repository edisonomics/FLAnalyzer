#!/bin/csh

#
# Example conversion and processing of 1D spectral series. frank.delaglio@nist.gov 2/12/2023
#  Input:  file "meta.tab" lists the data directories and titles for each spectrum.
#  Output: a series of scaled, interpolated spectra interp/*.ft1
#
# This demo data is a urine spectral series, with varying spike-in amounts of a 
# three-compound mixture.
#
# NMRPipe workflows for batch processing usually consist of a combination of 
# general-purpose utilities used via customized scripts. The batch processing 
# schemes often use a table of metadata as input. This table specifies the 
# locations of the spectrometer data directories to be processed, and also 
# specifies titles for each of the spectra.
#
# Example format of "meta.tab":
#
#  VARS   INDEX DIR_NAME TITLE
#  FORMAT %3d   %10s     %s
#
#   1  1 spike0-urine540ul-buf60ul-spike0ul
#   2  2 spike1-urine540ul-buf60ul-spike20ul
#   ... etc ...
#   7  7 buf-d2o540ul-buffer60ul-spike0ul
#
# To adopt this scheme to other data, create a "meta.tab" file and adjust the processing options in
# this script to suit. This will usually require adjusting auto-phase and baseline correction details.
#---------------------------------------------------------------------------------------------------------

#
# See "basicFT1.com -help":
#  P0 autophase, exp broaden 0.3 Hz, auto first-order baseline correction, auto phase in 0.1 degree steps.

set procArgs = "-xP0 Auto -xELB 0.3 -xBASEARG POLY,auto,window=2%,ord=1 -apOrd 1 -apArgs apxP0Step=0.1,apx1=5%,apxn=95%"

#
#  Delete any previous results.
#  Conversion with compensation for digital oversampling.
#  Processing with zero-order auto phase, and auto first-order baseline correction.
#  Optional step, scale series so that global max over 4.5ppm to 0.5ppm is 100.
#  Chemical shift reference by DSS signal.
#  Optional step, interpolate spectra to identical ppm range.
#  Display the results.

clean.com

conv.com -meta meta.tab -outDir fid -cmnd bruker -AUTO -dmx
proc.com -meta meta.tab -outDir ft  -procArgs $procArgs

scale1DSeries.com -in ft/*.ft1 -x1 4.5ppm -xn 0.5ppm -max 100.0

ref1D.com -in ft/*.ft1 -x1 0.1ppm -xn -0.1ppm

interp1D.com -inDir ft -outDir interp -ref None

show.com -inDir interp

