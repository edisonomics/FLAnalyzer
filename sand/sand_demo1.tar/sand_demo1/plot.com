#!/bin/csh

/bin/rm -f roi.ps roi.pdf
 
set inList    = (ft/*.ft1)
set colorList = (`specColors.tcl -rainbow -in $inList`)

plotSeries.tcl $* -in $inList -colors $colorList -rev


