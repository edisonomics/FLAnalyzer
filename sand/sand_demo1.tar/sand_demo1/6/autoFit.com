#!/bin/csh -f

set specName    = test.ft1
set simName     = sim.ft1
set simDir      = .
set difName     = dif.ft1
set difDir      = .
set inTabName   = test.tab
set auxTabName  = axt.tab
set outTabName  = nlin.tab
set errTabName  = err.nlin.tab
set noiseRMS    = 2.055009e+04
set specCount   = 1

set aRegSizeX  = 9
set dRegSizeX  = 9
set maxDX      = 1.94
set minXW      = 0.0
set maxXW      = 15.53
set simSizeX   = 32768


cp $inTabName $auxTabName


nlinLS \
 -tol 1.0e-8 -maxf 750 -iter 750 \
 -in $auxTabName -out $outTabName -data $specName \
 -apod  None \
 -noise $noiseRMS \
 -mod    LORENTZ1D  \
 -delta  X_AXIS $maxDX  \
 -limit  XW $minXW $maxXW \
 -w      $dRegSizeX  \
 -nots -norm -ppm

if (!(-e $simDir)) then
   mkdir $simDir
endif

nmrPipe -in $specName -out $simName -fn SET -r 0.0 -verb -ov

simSpecND -in $outTabName -data $simName \
          -mod   LORENTZ1D  \
          -w     $simSizeX  \
          -apod None -nots -verb


if (!(-e $difDir)) then
   mkdir $difDir
endif

addNMR -in1 $specName -in2 $simName -out $difName -sub
