#!/bin/csh

genericClean.com 

bruker -AUTO
fid.com

basicFT1.com -xP0 Auto -xP1 0 -xBASEARG POLY,auto,ord=0,window=2% \
             -apOrd 0 -apArgs apx1=12ppm,apxn=-2ppm,apMode=balance,apBDX=1.0ppm,apxP0Step=0.1,apsx1=5.1ppm,apsxn=4.3ppm

# basicFT1.com -xP0 Auto -xP1 0 -apOrd 0 -apArgs apx1=-0.5ppm,apxn=-2.5ppm,apMode=rms

#basicFT1.com -xP0 Auto -xP1 0 -apOrd -1 -apArgs apx1=0.2ppm,apxn=-0.2ppm

ref1D.tcl -in test.ft1 -x1 0.3ppm -xn -0.3ppm -max -tab ref.tab

