#!/bin/csh

nmrPipe -in test.fid \
| nmrPipe -fn PS -p0 5.9 -p1 0.0 \
| nmrPipe -fn MEM -sigma 900.0 -conv EM -cQ1 0.5 -alpha 1.0e-6 -itmax 200 -report 2 -verb -out mem.ft1 -ov

exit

nmrPipe -in test.fid -fn ML -p0 5.9 -p1 0.0 -sigma 900.0 -lw 0.7 -report 2 -verb -out ml.ft1 -ov
