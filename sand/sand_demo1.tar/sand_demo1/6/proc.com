#!/bin/csh

basicFT1.com -xP0 Auto -apOrd 1 -xBASEARG POLY,auto,window=2% -apArgs apxP0Step=0.1
