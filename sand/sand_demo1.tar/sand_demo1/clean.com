#!/bin/csh

genericClean.com -fList roi.ps roi.pdf

foreach d (1 2 3 4 5 6 7)
   cd $d
      genericClean.com
   cd ../
end

@ i = 1

while ($i <= 9999)
   set d = (`nmrPrintf "sand%04d" $i`)

   if (-d $d) then
      echo $d
      /bin/rm -rf $d
   else
      break
   endif

   @ i++
end
