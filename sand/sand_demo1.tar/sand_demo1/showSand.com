#!/bin/csh

if (`flagLoc $argv -help`) then
   echo "Show Results of SAND Analysis:"
   echo " -sandID sID  [Auto] SAND Master Directory ID (for sand0001 sand0002 etc)."
   echo " -specID ftID [1]    Spectrum ID."
   exit 0
endif

set sandID = (`getArgD $argv -sandID Auto`)
set specID = (`getArgD $argv -specID 1`)

if (`string csame $sandID Auto`) then
   @ sandID = 1
   @ nextID = 2

   while ($sandID <= 9999)
     set thisDir = (`nmrPrintf sand%04d $sandID`)
     set nextDir = (`nmrPrintf sand%04d $nextID`)

     if ((-d $thisDir) && !(-d $nextDir)) then
        echo "Auto-mode SAND Input. sandID: $sandID Input Directory: $thisDir"
        break
     endif

     @ sandID++
     @ nextID++
   end
endif

set sandDir = (`nmrPrintf sand%04d $sandID`)

if (!(-d $sandDir)) then
   echo "Error finding SAND input directory $sandDir"
   exit 1
endif

echo "$sandDir Spectrum $specID ..."

#
# SAND.sh direct output:
#  $sandDir/sand_data/$specID/SAND/sand_output/deconvoluted_signals_ft/sum_signals.ft

set specStr = (`nmrPrintf "%04d" $specID`)

if (-d $sandDir/simAll) then
   specView.tcl $* -in $sandDir/sand_data/$specID/test.ft \
                       $sandDir/sand_data/$specID/sim.ft1 \
                       $sandDir/simAll/$specID/*.ft1
else
   specView.tcl $* -in $sandDir/sand_data/$specID/test.ft \
                       $sandDir/sand_data/$specID/sim.ft1 
endif

