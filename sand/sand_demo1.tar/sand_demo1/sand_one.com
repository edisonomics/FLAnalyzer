#!/bin/csh

#
# Apply SAND to spectrum 001

sand1D.com -in interp/001-*.ft1 -x1 9.5ppm -xn -0.5ppm -simAll

