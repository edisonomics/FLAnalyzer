#!/bin/csh

set inDir = (`getArgD $argv -inDir interp`)

specView.tcl $* -in $inDir/*.ft1
