#!/bin/csh

#
# Execute SAND on a small region of two spectra.
# The parameters are set to produce a result quickly by allowing only 3 signals per bin (-s 3).

sand1D.com -in ./interp/001-*.ft1 ./interp/002-*.ft1 -x1 2.65ppm -xn 2.45ppm -simAll -sandArgs -s 3
