#!/bin/csh

if (`flagLoc $argv -help`) then
   echo "Interpolate a Series of 1D Spectra:"
   echo " -inDir     inDir    [ft]     Input Directory of .ft1 Files."
   echo " -outDir    outDir   [interp] Output Directory for .ft1 Files."
   echo " -ref       refName  [Auto]   Reference Spectrum for Interpolation."
   exit 0
endif

set inDir    = (`getArgD $argv -inDir  ft`)
set outDir   = (`getArgD $argv -outDir interp`)
set refName  = (`getArgD $argv -ref    Auto`)

if (!(-d $inDir)) then
   echo "Interpolate Error Finding Input Directory $inDir"
   exit 1
endif

set origDir = (`pwd`)

cd $inDir
   set inDirFull = (`pwd`)
   set fList     = (*.ft1)
cd $origDir 

set n = $#fList

if ($n < 2) then
   echo "Interpolate Error Finding Two or More Input Files $inDir/*.ft1"
   exit 1
endif

if (`string csame $refName None`) then
   set refName = $inDir/$fList[1]
   echo "Interpolation: Using Default Reference $refName (First in List)."
endif

if (`string csame $refName Auto`) then
   echo "Interpolation: Auto Mode. Finding Spectrum with Max RMS ..."
   set refName = (`getMaxSpec.com -in $inDir/*.ft1 -stat vRMS`)
endif

/bin/rm -rf $outDir 
mkdir $outDir 

echo ""

foreach f ($fList)
   echo Interpolating $inDir/$f to $outDir/$f Ref: $refName `interpNMR -ref $refName -in $inDir/$f -out $outDir/$f`
end 
