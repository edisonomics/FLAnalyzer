#!/bin/csh

if (`flagLoc $argv -help`) then
   echo "DSS Chemical Shift Calibration of a 1D Series:"
   echo " -in     inList [ft/*.ft1]   List of Input Spectra"
   echo " -x1     x1     [0.1ppm]     X-Axis Start of DSS Peak Region."
   echo " -xn     xn     [-0.1ppm]    X-Axis End of DSS Peak Region."
   echo " -verb                       Verbose Mode ON (Default)."
   echo " -noverb                     Verbose Mode OFF."
   exit 0
endif

if (-d ft) then
   set thisList = (`find ft -name \*.ft1 -print`)

   if ($#thisList != 0) then
      set thisList = (ft/*.ft1)
   else
      set thisList = (test.ft1)
   endif
else
   set thisList = (test.ft1)
endif

set inList    = (`getListArgD $argv -in -- $thisList`)

set x1        = (`getArgD $argv -x1   0.1ppm`)
set xn        = (`getArgD $argv -xn   -0.1ppm`)

@ vFlag = 1

if (`flagLoc $argv -verb`) then
   @ vFlag = 1
endif

if (`flagLoc $argv -noverb`) then
   @ vFlag = 0
endif

@ i = 0

if ($vFlag) then
   echo ""
   echo "DSS Chemical Shift Calibration:"
endif

foreach inName ($inList)
   @ i++

   if (!(-e $inName)) then
      echo "ref1D. Error Finding Input $i $inName"
      exit 1
   endif

   if ($vFlag) then
      echo ""
      ref1D.tcl -in $inName -x1 $x1 -xn $xn -max -tab ref.tab -verb
   else
      ref1D.tcl -in $inName -x1 $x1 -xn $xn -max -tab ref.tab -noverb
   endif

   /bin/rm -f ref.tab
end

exit 0
