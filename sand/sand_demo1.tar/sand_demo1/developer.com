#!/bin/csh

#
# Set options to run the development version of SAND.
# Apply SAND to spectrum 001

#
# alias  PRESAND     /public/groups/sand/fdelaglio/sandV8/PRESAND.sh
# alias  SAND        /public/groups/sand/fdelaglio/sandV8/SAND.sh
# alias  SUBMITSAND  /public/groups/sand/fdelaglio/sandV8/SUBMITSAND.sh
# setenv SANDPATH    /public/groups/sand/fdelaglio/sandV8 

set sandPath = /public/groups/sand/fdelaglio/sandV8
set devArgs  = (-presandCmnd $sandPath/PRESAND.sh -sandCmnd $sandPath/SAND.sh -submitsandCmnd $sandPath/SUBMITSAND.sh)

setenv SANDPATH $sandPath

#
# Options for "quick" SAND for debugging:
#  3 signals max per bin: -sandArgs -s 3 --
#  10 iterations max:     -sandArgs -n 10 --

sand1D.com -in interp/001-*.ft1 -x1 8.7ppm -xn 6.7ppm -simAll $devArgs -sandArgs -s 3 --

