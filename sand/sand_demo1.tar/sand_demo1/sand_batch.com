#!/bin/csh

#
# Apply SAND to all spectra:
# Note! HTCondor options for distributed processing (-condor) have not been tested.

sand1D.com -in interp/*.ft1 -x1 9.5ppm -xn -0.5ppm -simAll -condor

