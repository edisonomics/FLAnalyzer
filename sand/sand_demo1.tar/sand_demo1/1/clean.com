#!/bin/csh

genericClean.com -fList ref.tab nmr.com nmr_ft.com

@ i = 1

while ($i <= 9999)
   set d = (`nmrPrintf "sand%04d" $i`)

   if (-d $d) then
      echo $d
      /bin/rm -rf $d
   else
      break
   endif

   @ i++
end
