#!/bin/csh

bruk2pipe -verb -in ./fid \
  -bad 0.0 -ext -aswap -DMX -decim 2080 -dspfvs 21 -grpdly 76  \
  -xN             32768  \
  -xT             16384  \
  -xMODE            DQD  \
  -xSW         9615.385  \
  -xOBS         600.133  \
  -xCAR           4.773  \
  -xLAB              1H  \
  -ndim               1  \
| nmrPipe -fn MULT -c 2.44141e-01 \
  -out ./test.fid -ov

