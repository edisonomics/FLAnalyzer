#!/bin/csh

#
# Delete any previous results.
# Create a conversion script "fid.com" with *oversampling correction* (bruker -dmx).
# Execute the conversion script to create "test.fid"
# Process the spectrum with autophase and baseline correction to create "test.ft1".
# Adjust ppm calibration via DSS signal.
#
# P0 autophase (-xP0 Auto) exp broaden 0.3 Hz (-xELB 0.3), auto first-order baseline
# correction (-xBASEARG POLY,auto,window=2%,ord=1), auto phase with temporary first-order
# baseline correction (-apOrd 1) using 0.1 degree steps (-apArgs apxP0Step=0.1).

clean.com

bruker -AUTO -dmx -script fid.com -out test.fid
fid.com

basicFT1.com -in test.fid -out test.ft1 \
             -xP0 Auto -xELB 0.3 -xBASEARG POLY,auto,window=2%,ord=1 \
             -apOrd 1 -apArgs apxP0Step=0.1 -title spike0-urine540ul-buf60ul-spike0ul

ref1D.tcl -in test.ft1 -x1 0.1ppm -xn -0.1ppm -max -tab ref.tab

specView.tcl -in test.ft1
